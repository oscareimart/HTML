function Header() {
  return <h1>Gym Manager Pro </h1>;
}

export default Header;
