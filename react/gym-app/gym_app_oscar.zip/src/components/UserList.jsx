import TrainingPlan from "./TrainingPlan";

function UserList({ users }) {
  return (
    <div>
      <h2>Usuarios Registrados</h2>
      {users.length === 0 && <p>No hay Usuarios aun</p>}

      {users.map((user) => (
        <div key={user.id} className="item">
          <p>{user.name}</p>
          <TrainingPlan plan={user.plan} />
        </div>
      ))}
    </div>
  );
}

export default UserList;
