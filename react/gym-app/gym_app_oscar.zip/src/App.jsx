import { useEffect, useState } from "react";
import Header from "./components/Header";
import RegisterFormUser from "./components/RegisterFormUser";
import RegisterFormDiet from "./components/RegisterFormDiet";
import UserList from "./components/UserList";
import DietList from "./components/DietList";
import "./App.css";

function App() {
  const [users, setUsers] = useState([]);
  const [diets, setDiets] = useState([]);

  useEffect(() => {
    console.log(users);
  }, [users]);

  return (
    <div>
      <Header />
      <div className="content">
        <div className="card">
          <RegisterFormUser users={users} setUsers={setUsers} />
          <UserList users={users} />
        </div>
        <div className="card">
          <RegisterFormDiet diets={diets} setDiet={setDiets} />
          <DietList diets={diets} />
        </div>
      </div>
    </div>
  );
}

export default App;
